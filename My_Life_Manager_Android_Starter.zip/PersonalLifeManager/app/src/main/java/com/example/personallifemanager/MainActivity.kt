package com.example.personallifemanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*

data class AppSection(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val description: String
)

private val sections = listOf(
    AppSection("home", "Home", Icons.Default.Home, "Your personal overview"),
    AppSection("sleep", "Sleep", Icons.Default.Bedtime, "Record sleep and wake times"),
    AppSection("finance", "Finance", Icons.Default.AccountBalanceWallet, "Income, expenses, assets and liabilities"),
    AppSection("trading", "Trading", Icons.Default.ShowChart, "Trading journal and holdings"),
    AppSection("activity", "Activities", Icons.Default.Timer, "Create and track your own activities"),
    AppSection("planner", "Planner", Icons.Default.EventNote, "Plan tasks and review your day"),
    AppSection("diary", "Diary", Icons.Default.Lock, "Private diary (security setup pending)"),
    AppSection("screen", "Screen time", Icons.Default.PhoneAndroid, "Screen-time tracking (native permission setup pending)"),
    AppSection("reports", "Reports", Icons.Default.Assessment, "Daily to yearly reports and statements")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LifeManagerApp() }
    }
}

@Composable
fun LifeManagerApp() {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: "home"

    MaterialTheme(colorScheme = lightColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("My Life Manager", fontWeight = FontWeight.Bold)
                            Text("Your personal control centre", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    val bottomItems = sections.take(4)
                    bottomItems.forEach { item ->
                        NavigationBarItem(
                            selected = currentRoute == item.route,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = "home",
                modifier = Modifier.padding(padding)
            ) {
                sections.forEach { item ->
                    composable(item.route) {
                        if (item.route == "home") {
                            HomeScreen(onOpen = { navController.navigate(it) })
                        } else {
                            ModuleScreen(item)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBar(title: @Composable () -> Unit) {
    androidx.compose.material3.TopAppBar(title = title)
}

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Welcome 👋", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Start by adding your own information. No sample activity or financial records are preloaded.")
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Today at a glance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text("No records yet")
                    Text("Your totals and summaries will appear here after you add entries.",
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        items(sections.drop(1)) { item ->
            Card(
                onClick = { onOpen(item.route) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(item.icon, contentDescription = null)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.label, fontWeight = FontWeight.SemiBold)
                        Text(item.description, style = MaterialTheme.typography.bodySmall)
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = "Open")
                }
            }
        }
    }
}

@Composable
fun ModuleScreen(section: AppSection) {
    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(section.icon, contentDescription = null, modifier = Modifier.size(36.dp))
        Text(section.label, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(section.description)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Module setup", fontWeight = FontWeight.SemiBold)
                Text("This is the first app foundation. The working forms, local database, calculations and reports will be added module by module.")
                Text("Your data will not be sent anywhere in this starter version.")
            }
        }
    }
}
