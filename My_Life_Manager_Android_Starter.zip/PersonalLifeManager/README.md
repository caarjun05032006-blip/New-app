# My Life Manager — Android starter

This is the first native Android project foundation for your personal management app.

## Included now
- Native Android app shell using Kotlin and Jetpack Compose
- Home dashboard
- Navigation entry points for Sleep, Finance, Trading, Activities, Planner, Diary, Screen Time and Reports
- No fake sample records and no predefined activities

## Not implemented yet
- Persistent database and data entry forms
- Financial ledger, year-wise Balance Sheet and P&L
- Trading calculations and holdings
- Encrypted diary and app lock
- Native Android per-app screen-time permission integration
- PDF reports, backup and restore

## Build
Open this folder in Android Studio, allow Gradle sync, then run the `app` configuration on an Android device or emulator.

To create an APK in Android Studio:
Build -> Build Bundle(s) / APK(s) -> Build APK(s)

Package: `com.example.personallifemanager`
Minimum Android: 8.0 (API 26)
